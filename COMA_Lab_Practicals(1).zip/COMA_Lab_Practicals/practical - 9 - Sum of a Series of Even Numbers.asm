    LXI H, 2050H
    MOV C, M
    MVI B, 00H
LOOP: INX H
    MOV A, M
    ANI 01H
    JNZ SKIP
    MOV A, B
    ADD M
    MOV B, A
SKIP: DCR C
    JNZ LOOP
    MOV A, B
    STA 2055H
    HLT

; EXPERIMENT 9: Sum of a series of even numbers using 8085
;
; Aim: Add only the even numbers in a block of N 8-bit numbers (count at 2050H, data from 2051H) and store the sum at 2055H.
;
; Theory: A number is even if its least significant bit (bit 0) is 0. ANI 01H clears every bit except bit 0, so the result is 00H (Zero flag set) for an even number and 01H (Zero flag clear) for an odd number. Each even number is added to a running sum kept in register B; odd numbers are skipped. The sum is kept in B because A is needed for the bit test.
;
; Memory map: 2050H = count (05H); 2051H-2055H = 02H, 03H, 04H, 05H, 06H; 2055H also receives the sum (0CH), overwriting the last data byte.
;
; Program explanation:
;   LXI H, 2050H / MOV C, M   C = count
;   MVI B, 00H                B = sum = 0
;   LOOP: INX H / MOV A, M    A = next element
;   ANI 01H / JNZ SKIP        bit 0 = 1 means odd: skip it
;   MOV A, B / ADD M / MOV B, A   add the even number to the sum
;   SKIP: DCR C / JNZ LOOP    repeat for all elements
;   MOV A, B / STA 2055H      store the sum
;   HLT                       stop
;
; Result: even numbers 02H, 04H, 06H give a sum of 0CH (12 decimal).
; Limitation: the count must be at least 1.
