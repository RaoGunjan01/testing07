    LDA 2050H
    MVI B, 00H
    MVI C, 00H
HUNDREDS:
    CPI 64H
    JC TENS
    SUI 64H
    INR B
    JMP HUNDREDS
TENS:
    CPI 0AH
    JC UNITS
    SUI 0AH
    INR C
    JMP TENS
UNITS:
    MOV D, A
    MOV A, C
    RLC
    RLC
    RLC
    RLC
    ADD D
    STA 2052H
    MOV A, B
    STA 2051H
    HLT

; EXPERIMENT 7 - PART B: Convert a binary number to BCD using 8085
;
; Aim: Convert the binary number at 2050H to BCD. Store the hundreds digit at 2051H and the packed tens-units digits at 2052H.
;
; Theory: The binary number is divided by powers of 10 using repeated subtraction. First 100 (64H) is subtracted repeatedly; the number of subtractions is the hundreds digit. Then 10 (0AH) is subtracted repeatedly to get the tens digit. What remains is the units digit. The tens digit is moved to the upper nibble (four RLC rotations) and combined with the units digit to give packed BCD.
;
; Memory map: 2050H = binary number (FFH = 255); 2051H = hundreds digit (02H); 2052H = packed tens and units (55H).
;
; Program explanation:
;   LDA 2050H; B = 0 (hundreds counter); C = 0 (tens counter)
;   HUNDREDS: CPI 64H / JC TENS   if A < 100 go to the tens step
;   SUI 64H / INR B / JMP HUNDREDS   subtract 100, count it, repeat (255 gives B = 2 and leaves A = 37H, which is 55 decimal)
;   TENS: CPI 0AH / JC UNITS      if A < 10 the rest is the units digit
;   SUI 0AH / INR C / JMP TENS    subtract 10, count it, repeat (5 times)
;   UNITS: MOV D, A               D = units digit (5)
;   MOV A, C / RLC x 4            tens digit moved to the upper nibble: A = 50H
;   ADD D / STA 2052H             A = 55H stored as packed tens-units
;   MOV A, B / STA 2051H          hundreds digit stored
;   HLT                           stop
;
; Result: binary FFH (255) converts to BCD 02H and 55H, that is 255.
