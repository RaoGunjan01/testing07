    LDA 2051H
    MOV B, A
    LDA 2050H
    SUB B
    STA 2052H
    HLT

; EXPERIMENT 1 - PART C: Subtraction of two 8-bit numbers using 8085
;
; Aim: Subtract the subtrahend (2051H) from the minuend (2050H) and store the difference at 2052H.
;
; Theory: SUB subtracts a register from the Accumulator (A = A - register). The subtrahend is loaded first and saved in a register, then the minuend is loaded into A and SUB is executed. If the subtrahend is larger than the minuend the Carry (borrow) flag is set and the result is in 2's complement form.
;
; Memory map: 2050H = minuend (38H), 2051H = subtrahend (15H), 2052H = difference (23H).
;
; Program explanation:
;   LDA 2051H   A = 15H (subtrahend)
;   MOV B, A    B = 15H
;   LDA 2050H   A = 38H (minuend)
;   SUB B       A = 38H - 15H = 23H
;   STA 2052H   store the difference
;   HLT         stop
;
; Result: 38H - 15H = 23H (56 - 21 = 35 decimal).
