    LHLD 2050H
    XCHG
    LHLD 2052H
    DAD D
    SHLD 2054H
    HLT

; EXPERIMENT 1 - PART B: Addition of two 16-bit numbers using 8085
;
; Aim: Add the 16-bit numbers at 2050H-2051H and 2052H-2053H (LSB first) and store the 16-bit sum at 2054H-2055H.
;
; Theory: The 8085 adds 16-bit values with DAD (Double Add), which adds a register pair (B, D or H) to the HL pair. LHLD loads HL from two consecutive memory locations (low byte from the lower address into L, high byte from the next address into H). XCHG swaps HL and DE. SHLD stores HL back to memory (L to the lower address, H to the next). The Carry flag is set if the 16-bit sum exceeds FFFFH.
;
; Memory map: 2050H = 50H, 2051H = 10H (first number 1050H); 2052H = B0H, 2053H = 20H (second number 20B0H); 2054H = 00H, 2055H = 31H (sum 3100H).
;
; Program explanation:
;   LHLD 2050H  HL = 1050H
;   XCHG        DE = 1050H, HL is free
;   LHLD 2052H  HL = 20B0H
;   DAD D       HL = HL + DE = 3100H (Carry = 0)
;   SHLD 2054H  L = 00H stored at 2054H, H = 31H stored at 2055H
;   HLT         stop
;
; Result: 1050H + 20B0H = 3100H.
