    LDA 2050H
    MOV B, A
    LDA 2051H
    CMP B
    JC STORE
    MOV A, B
STORE:
    STA 2052H
    HLT

; EXPERIMENT 4 - PART A: Minimum of two 8-bit numbers using 8085
;
; Aim: Find the smaller of the numbers at 2050H and 2051H and store it at 2052H.
;
; Theory: CMP compares the Accumulator with an operand by computing A - operand internally without storing the result. If A < operand the Carry flag is set; if A >= operand Carry is cleared (Zero is set when they are equal). Checking Carry after CMP tells which number is smaller.
;
; Memory map: 2050H = first number (45H), 2051H = second number (2AH), 2052H = minimum (2AH).
;
; Program explanation:
;   LDA 2050H / MOV B, A   B = first number
;   LDA 2051H              A = second number
;   CMP B                  computes A - B: Carry = 1 when A < B
;   JC STORE               Carry set, so A is the minimum; jump to STORE
;   MOV A, B               otherwise B is the minimum, move it to A
;   STORE: STA 2052H       store the minimum
;   HLT                    stop
;
; Result: minimum of 45H and 2AH is 2AH (42 decimal).
