    LDA 2050H
    MOV B, A
    ANI 0F0H
    RRC
    RRC
    RRC
    RRC
    MOV C, A
    ADD A
    ADD A
    ADD C
    ADD A
    MOV C, A
    MOV A, B
    ANI 0FH
    ADD C
    STA 2051H
    HLT

; EXPERIMENT 7 - PART A: Convert a BCD number to binary using 8085
;
; Aim: Convert the packed BCD number at 2050H into its binary equivalent and store it at 2051H.
;
; Theory: In packed BCD each nibble holds one decimal digit (65 decimal is stored as 65H = 0110 0101). To convert: take the upper nibble (tens digit), multiply it by 10, and add the lower nibble (units digit). Multiplying by 10 is done with additions: x -> 2x -> 4x -> 5x (add x again) -> 10x (double 5x).
;
; Memory map: 2050H = BCD number (65H); 2051H = binary result (41H = 65 decimal).
;
; Program explanation:
;   LDA 2050H / MOV B, A   A = 65H, copy kept in B
;   ANI 0F0H               mask the upper nibble: A = 60H
;   RRC x 4                rotate right four times: A = 06H (tens digit)
;   MOV C, A               C = tens digit (6)
;   ADD A / ADD A          A = 2 x 6 = 0CH, then 4 x 6 = 18H
;   ADD C                  A = 5 x 6 = 1EH
;   ADD A                  A = 10 x 6 = 3CH
;   MOV C, A               C = 3CH (60 decimal)
;   MOV A, B / ANI 0FH     A = units digit = 05H
;   ADD C                  A = 05H + 3CH = 41H
;   STA 2051H / HLT        store the result and stop
;
; Result: BCD 65H converts to binary 41H (6 x 10 + 5 = 65).
