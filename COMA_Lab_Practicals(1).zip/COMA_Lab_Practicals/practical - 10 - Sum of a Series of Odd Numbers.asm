    LXI H, 2050H
    MOV C, M
    MVI B, 00H
LOOP: INX H
    MOV A, M
    ANI 01H
    JZ SKIP
    MOV A, B
    ADD M
    MOV B, A
SKIP: DCR C
    JNZ LOOP
    MOV A, B
    STA 2055H
    HLT

; EXPERIMENT 10: Sum of a series of odd numbers using 8085
;
; Aim: Add only the odd numbers in a block of N 8-bit numbers (count at 2050H, data from 2051H) and store the sum at 2055H.
;
; Theory: A number is odd if bit 0 is 1. ANI 01H isolates bit 0: the result is 01H (non-zero) for an odd number. This program is the same as the even-sum program except that the jump condition is reversed: JZ SKIP (skip when bit 0 is 0, that is when the number is even) instead of JNZ SKIP.
;
; Memory map: 2050H = count (05H); 2051H-2055H = 02H, 03H, 04H, 05H, 06H; 2055H also receives the sum (08H), overwriting the last data byte.
;
; Program explanation:
;   LXI H, 2050H / MOV C, M   C = count
;   MVI B, 00H                B = sum = 0
;   LOOP: INX H / MOV A, M    A = next element
;   ANI 01H / JZ SKIP         Zero flag set means even: skip it
;   MOV A, B / ADD M / MOV B, A   add the odd number to the sum
;   SKIP: DCR C / JNZ LOOP    repeat for all elements
;   MOV A, B / STA 2055H      store the sum
;   HLT                       stop
;
; Result: odd numbers 03H and 05H give a sum of 08H.
; Limitation: the count must be at least 1.
