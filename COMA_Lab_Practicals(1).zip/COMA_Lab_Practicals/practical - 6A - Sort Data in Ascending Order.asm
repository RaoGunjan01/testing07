    LDA 2050H
    CPI 02H
    JC HALT
    DCR A
    MOV D, A
OUTER:
    LDA 2050H
    DCR A
    MOV C, A
    LXI H, 2051H
INNER:
    MOV A, M
    INX H
    CMP M
    JC SKIP
    JZ SKIP
    MOV B, M
    MOV M, A
    DCX H
    MOV M, B
    INX H
SKIP:
    DCR C
    JNZ INNER
    DCR D
    JNZ OUTER
HALT:
    HLT

; EXPERIMENT 6 - PART A: Sort data in ascending order using 8085
;
; Aim: Sort N 8-bit numbers (count at 2050H, data from 2051H) in ascending order, in place, using Bubble Sort.
;
; Theory: Bubble Sort repeatedly walks through the list comparing adjacent elements and swaps them if they are out of order. For ascending order, a pair is swapped when the current element is greater than the next. N-1 passes are needed; after each pass the largest unsorted element has "bubbled" to its final position. The outer counter D controls the passes and the inner counter C controls the comparisons in a pass.
;
; Memory map: 2050H = count (05H); 2051H-2055H before = 50H, 20H, 40H, 10H, 30H; after = 10H, 20H, 30H, 40H, 50H.
;
; Program explanation:
;   LDA 2050H / CPI 02H / JC HALT   fewer than 2 elements: nothing to sort
;   DCR A / MOV D, A                D = N-1 passes
;   OUTER: reload count, C = N-1 comparisons, HL = 2051H (first element)
;   INNER: MOV A, M                 A = current element
;   INX H                           HL points to the next element
;   CMP M                           compare current (A) with next ([HL])
;   JC SKIP / JZ SKIP               current <= next: already in order
;   MOV B, M / MOV M, A             swap: next gets the larger value
;   DCX H / MOV M, B / INX H        current gets the smaller value, HL restored
;   SKIP: DCR C / JNZ INNER         finish the pass
;   DCR D / JNZ OUTER               next pass
;   HALT: HLT                       stop
;
; Result: data sorted ascending: 10H, 20H, 30H, 40H, 50H.
