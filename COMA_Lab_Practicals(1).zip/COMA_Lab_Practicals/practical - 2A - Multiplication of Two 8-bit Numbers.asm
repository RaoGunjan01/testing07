    LDA 2050H
    MOV D, A
    LDA 2051H
    MOV C, A
    ORA A
    MVI A, 00H
    JZ STORE
LOOP: ADD D
    DCR C
    JNZ LOOP
STORE:
    STA 2052H
    HLT

; EXPERIMENT 2 - PART A: Multiplication of two 8-bit numbers using 8085
;
; Aim: Multiply the multiplicand at 2050H by the multiplier at 2051H and store the product at 2052H.
;
; Theory: The 8085 has no multiply instruction, so multiplication is done by repeated addition: the multiplicand is added to a running sum as many times as the multiplier. A zero check on the multiplier prevents the loop from running 256 times when the multiplier is 0. The product is kept in 8 bits here, so results above FFH are not handled.
;
; Memory map: 2050H = multiplicand (05H), 2051H = multiplier (03H), 2052H = product (0FH).
;
; Program explanation:
;   LDA 2050H / MOV D, A   D = multiplicand
;   LDA 2051H / MOV C, A   C = multiplier, used as the loop counter
;   ORA A                  sets the Zero flag if the multiplier is 0
;   MVI A, 00H             clear A (the running sum); MVI does not change the flags
;   JZ STORE               multiplier was 0, so store 0
;   LOOP: ADD D            A = A + multiplicand
;   DCR C                  decrement the counter
;   JNZ LOOP               repeat until C = 0
;   STA 2052H              store the product
;   HLT                    stop
;
; Result: 05H x 03H = 0FH (5 x 3 = 15).
