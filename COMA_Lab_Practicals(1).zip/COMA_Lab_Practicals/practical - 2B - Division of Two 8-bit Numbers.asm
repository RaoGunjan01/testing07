    LDA 2051H
    MOV C, A
    LDA 2050H
    MVI D, 00H
    MOV B, A
    MOV A, C
    ORA A
    MOV A, B
    JZ DONE
LOOP: CMP C
    JC DONE
    SUB C
    INR D
    JMP LOOP
DONE:
    STA 2053H
    MOV A, D
    STA 2052H
    HLT

; EXPERIMENT 2 - PART B: Division of two 8-bit numbers using 8085
;
; Aim: Divide the dividend at 2050H by the divisor at 2051H. Store the quotient at 2052H and the remainder at 2053H.
;
; Theory: The 8085 has no divide instruction, so division is done by repeated subtraction: the divisor is subtracted from the dividend until what is left is smaller than the divisor. The number of subtractions is the quotient and the value left in A is the remainder. CMP compares without changing A: it sets the Carry flag when A < operand. A zero divisor is detected first to avoid an endless loop.
;
; Memory map: 2050H = dividend (1FH), 2051H = divisor (05H), 2052H = quotient (06H), 2053H = remainder (01H).
;
; Program explanation:
;   LDA 2051H / MOV C, A   C = divisor
;   LDA 2050H              A = dividend
;   MVI D, 00H             D = quotient counter = 0
;   MOV B, A               backup of the dividend in B
;   MOV A, C / ORA A       test whether the divisor is zero
;   MOV A, B               restore the dividend (MOV does not change flags)
;   JZ DONE                divisor = 0, skip the division
;   LOOP: CMP C            compare A with the divisor
;   JC DONE                A < divisor, so the division is finished
;   SUB C                  A = A - divisor
;   INR D                  quotient = quotient + 1
;   JMP LOOP               repeat
;   DONE: STA 2053H        remainder (A) stored
;   MOV A, D / STA 2052H   quotient stored
;   HLT                    stop
;
; Result: 1FH / 05H = quotient 06H, remainder 01H (31 / 5 = 6 R 1).
