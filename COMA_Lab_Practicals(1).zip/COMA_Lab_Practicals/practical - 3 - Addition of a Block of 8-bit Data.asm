    LXI H, 2050H
    MOV C, M
    MVI A, 00H
LOOP: INX H
    ADD M
    DCR C
    JNZ LOOP
    STA 2055H
    HLT

; EXPERIMENT 3: Addition of a block of 8-bit data stored in memory
;
; Aim: Add N 8-bit numbers stored from 2051H onwards (count N at 2050H) and store the sum at 2055H.
;
; Theory: Block addition visits consecutive memory locations and accumulates the sum. The HL register pair is used as a memory pointer, and M means the memory byte addressed by HL. The count is kept in register C as the loop counter. In each pass the pointer moves to the next byte, ADD M adds it to A, and the counter is decremented. The loop ends when C reaches zero.
;
; Memory map: 2050H = count (04H); 2051H-2054H = data 10H, 20H, 30H, 40H; 2055H = sum (A0H).
;
; Program explanation:
;   LXI H, 2050H   HL points to the count
;   MOV C, M       C = count
;   MVI A, 00H     clear the running sum
;   LOOP: INX H    point to the next data byte
;   ADD M          A = A + [HL]
;   DCR C          decrement the counter
;   JNZ LOOP       repeat until C = 0
;   STA 2055H      store the sum
;   HLT            stop
;
; Result: 10H + 20H + 30H + 40H = A0H (160 decimal).
; Limitation: the count must be at least 1 (a count of 0 would make C wrap to FFH and loop 256 times), and the sum is limited to 8 bits.
