    LDA 2050H
    MOV B, A
    LDA 2051H
    CMP B
    JNC STORE
    MOV A, B
STORE:
    STA 2052H
    HLT

; EXPERIMENT 5 - PART A: Maximum of two 8-bit numbers using 8085
;
; Aim: Find the larger of the numbers at 2050H and 2051H and store it at 2052H.
;
; Theory: CMP computes A - operand internally. If A >= operand the Carry flag is cleared (A is larger or equal); if A < operand Carry is set. Checking Carry with JNC (jump if no carry) selects the maximum.
;
; Memory map: 2050H = first number (3CH), 2051H = second number (5AH), 2052H = maximum (5AH).
;
; Program explanation:
;   LDA 2050H / MOV B, A   B = first number
;   LDA 2051H              A = second number
;   CMP B                  5AH - 3CH = 1EH, no borrow, so Carry = 0
;   JNC STORE              A >= B, so A is the maximum; jump to STORE
;   MOV A, B               otherwise B is the maximum
;   STORE: STA 2052H       store the maximum
;   HLT                    stop
;
; Result: maximum of 3CH and 5AH is 5AH (90 decimal).
