    LDA 2050H
    CPI 02H
    JC HALT
    DCR A
    MOV D, A
OUTER:
    LDA 2050H
    DCR A
    MOV C, A
    LXI H, 2051H
INNER:
    MOV A, M
    INX H
    CMP M
    JNC SKIP
    MOV B, M
    MOV M, A
    DCX H
    MOV M, B
    INX H
SKIP:
    DCR C
    JNZ INNER
    DCR D
    JNZ OUTER
HALT:
    HLT

; EXPERIMENT 6 - PART B: Sort data in descending order using 8085
;
; Aim: Sort N 8-bit numbers (count at 2050H, data from 2051H) in descending order using Bubble Sort.
;
; Theory: Identical to the ascending sort except that adjacent elements are swapped when the current element is SMALLER than the next one. After sorting, the largest element is first and the smallest is last. The only change in the code is the jump condition after CMP: JNC SKIP (A >= next means the pair is already in descending order).
;
; Memory map: 2050H = count (05H); 2051H-2055H before = 50H, 20H, 40H, 10H, 30H; after = 50H, 40H, 30H, 20H, 10H.
;
; Program explanation:
;   Setup, OUTER and INNER loop control are the same as in Part A.
;   CMP M / JNC SKIP        current >= next: correct order for descending, skip the swap
;   MOV B, M / MOV M, A     otherwise swap: the larger value goes to the current position
;   DCX H / MOV M, B / INX H   completes the swap and restores HL
;   DCR C / JNZ INNER, DCR D / JNZ OUTER   loop control
;   HALT: HLT               stop
;
; Result: data sorted descending: 50H, 40H, 30H, 20H, 10H.
