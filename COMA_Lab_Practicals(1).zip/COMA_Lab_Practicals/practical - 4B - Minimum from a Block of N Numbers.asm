    LXI H, 2050H
    MOV C, M
    INX H
    MOV A, M
    DCR C
LOOP: INX H
    CMP M
    JC SKIP
    MOV A, M
SKIP: DCR C
    JNZ LOOP
    STA 2055H
    HLT

; EXPERIMENT 4 - PART B: Minimum from a block of N 8-bit numbers using 8085
;
; Aim: Find the smallest of N numbers (count at 2050H, data from 2051H) and store it at 2055H.
;
; Theory: The first element is taken as the initial minimum. Each following element is compared with the current minimum using CMP. If A < [HL] (Carry set) the current minimum is kept; otherwise (Carry clear) the minimum is replaced by [HL]. The process continues until every element has been compared.
;
; Memory map: 2050H = count (04H); 2051H-2054H = 35H, 12H, 48H, 07H; 2055H = minimum (07H).
;
; Program explanation:
;   LXI H, 2050H / MOV C, M   C = count
;   INX H / MOV A, M          A = first element (initial minimum)
;   DCR C                     one element is already processed
;   LOOP: INX H               move to the next element
;   CMP M                     compare A with [HL]
;   JC SKIP                   A < [HL]: A is still the minimum
;   MOV A, M                  else update the minimum
;   SKIP: DCR C / JNZ LOOP    repeat for all elements
;   STA 2055H                 store the minimum
;   HLT                       stop
;
; Result: minimum of {35H, 12H, 48H, 07H} is 07H.
; Limitation: the count must be at least 2; with a count of 1 the counter wraps around after DCR C.
