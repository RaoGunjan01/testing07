    LDA 2050H
    MOV B, A
    LDA 2051H
    ADD B
    STA 2052H
    HLT

; EXPERIMENT 1 - PART A: Addition of two 8-bit numbers using 8085
;
; Aim: Add two 8-bit numbers stored at 2050H and 2051H and store the sum at 2052H.
;
; Theory: The 8085 adds with the ADD instruction, which adds a register to the Accumulator (A = A + register). The first number is loaded and saved in a register, the second number is loaded into A, ADD produces the sum in A, and STA stores it in memory. If the sum exceeds FFH the Carry flag is set (the program ignores it).
;
; Memory map: 2050H = first number (25H), 2051H = second number (1FH), 2052H = sum (44H).
;
; Program explanation:
;   LDA 2050H   load the byte at 2050H into the Accumulator (A = 25H)
;   MOV B, A    copy A to register B (B = 25H), freeing A
;   LDA 2051H   load the second number (A = 1FH)
;   ADD B       A = A + B = 1FH + 25H = 44H
;   STA 2052H   store A at memory location 2052H
;   HLT         stop the program
;
; Result: 25H + 1FH = 44H (37 + 31 = 68 decimal).
