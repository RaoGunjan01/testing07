    LDA 2050H
    MOV B, A
    ANI 0F0H
    RRC
    RRC
    RRC
    RRC
    CPI 0AH
    JC NUM1
    ADI 07H
NUM1:
    ADI 30H
    STA 2051H
    MOV A, B
    ANI 0FH
    CPI 0AH
    JC NUM2
    ADI 07H
NUM2:
    ADI 30H
    STA 2052H
    HLT

; EXPERIMENT 8 - PART A: Convert a binary number to ASCII using 8085
;
; Aim: Convert the hex byte at 2050H into two ASCII characters. Store the ASCII of the upper nibble at 2051H and of the lower nibble at 2052H.
;
; Theory: Every hex digit has an ASCII code. Digits 0-9 have codes 30H-39H (add 30H). Letters A-F have codes 41H-46H (add 30H + 07H = 37H). The byte is split into its upper and lower nibbles, and each nibble is converted separately: if the nibble is 0AH or more, 07H is added first, and then 30H is added.
;
; Memory map: 2050H = binary byte (9AH); 2051H = ASCII of the upper nibble (39H = "9"); 2052H = ASCII of the lower nibble (41H = "A").
;
; Program explanation:
;   LDA 2050H / MOV B, A       A = 9AH, copy kept in B
;   ANI 0F0H / RRC x 4         upper nibble moved down: A = 09H
;   CPI 0AH / JC NUM1          09H < 0AH (Carry set), skip the +07H
;   ADI 30H / STA 2051H        A = 39H stored
;   MOV A, B / ANI 0FH         lower nibble: A = 0AH
;   CPI 0AH / JC NUM2          0AH >= 0AH (no Carry), so the next line runs
;   ADI 07H / ADI 30H          0AH + 07H = 11H, + 30H = 41H
;   STA 2052H / HLT            41H stored, stop
;
; Result: 9AH converts to ASCII 39H ("9") and 41H ("A").
