    LDA 2050H
    SUI 30H
    CPI 0AH
    JC OK1
    SUI 07H
OK1:
    RLC
    RLC
    RLC
    RLC
    MOV B, A
    LDA 2051H
    SUI 30H
    CPI 0AH
    JC OK2
    SUI 07H
OK2:
    ADD B
    STA 2052H
    HLT

; EXPERIMENT 8 - PART B: Convert ASCII to binary using 8085
;
; Aim: Convert two ASCII characters (hex digits) stored at 2050H and 2051H into one binary byte stored at 2052H.
;
; Theory: This is the reverse of binary-to-ASCII conversion. For ASCII digits 0-9 (30H-39H) subtracting 30H gives the value. For letters A-F (41H-46H), subtracting 30H gives 11H-16H, so a further 07H is subtracted (total 37H). The first character gives the upper nibble: it is rotated left four times and then combined with the lower nibble from the second character. Only upper-case letters A-F are handled.
;
; Memory map: 2050H = ASCII of the upper nibble (34H = "4"); 2051H = ASCII of the lower nibble (46H = "F"); 2052H = binary byte (4FH).
;
; Program explanation:
;   LDA 2050H / SUI 30H        34H - 30H = 04H
;   CPI 0AH / JC OK1           04H < 0AH: it is a digit, skip the extra subtraction
;   OK1: RLC x 4               04H becomes 40H
;   MOV B, A                   B = 40H
;   LDA 2051H / SUI 30H        46H - 30H = 16H
;   CPI 0AH / JC OK2           16H >= 0AH: it is a letter
;   SUI 07H                    16H - 07H = 0FH
;   OK2: ADD B                 0FH + 40H = 4FH
;   STA 2052H / HLT            store and stop
;
; Result: ASCII "4" (34H) and "F" (46H) convert to the binary byte 4FH.
