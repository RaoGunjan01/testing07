    LXI H, 2050H
    MOV C, M
    INX H
    MOV A, M
    DCR C
LOOP: INX H
    CMP M
    JNC SKIP
    MOV A, M
SKIP: DCR C
    JNZ LOOP
    STA 2055H
    HLT

; EXPERIMENT 5 - PART B: Maximum from a block of N 8-bit numbers using 8085
;
; Aim: Find the largest of N numbers (count at 2050H, data from 2051H) and store it at 2055H.
;
; Theory: Same method as the minimum program. The first element is the initial maximum. Each next element is compared with it using CMP. If A < [HL] (Carry set) a larger value has been found and the maximum is updated; if A >= [HL] (JNC) the current maximum stays.
;
; Memory map: 2050H = count (04H); 2051H-2054H = 15H, 72H, 3BH, 56H; 2055H = maximum (72H).
;
; Program explanation:
;   LXI H, 2050H / MOV C, M   C = count
;   INX H / MOV A, M          A = first element (initial maximum)
;   DCR C                     one element is already processed
;   LOOP: INX H               move to the next element
;   CMP M                     compare A with [HL]
;   JNC SKIP                  A >= [HL]: keep the maximum
;   MOV A, M                  else A = [HL]
;   SKIP: DCR C / JNZ LOOP    repeat for all elements
;   STA 2055H                 store the maximum
;   HLT                       stop
;
; Result: maximum of {15H, 72H, 3BH, 56H} is 72H (114 decimal).
; Limitation: the count must be at least 2.
