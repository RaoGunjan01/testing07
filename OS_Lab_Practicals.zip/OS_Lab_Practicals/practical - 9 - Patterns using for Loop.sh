#!/bin/sh
echo "Pattern 1: Right triangle"
for i in 1 2 3 4 5
do
    for j in `seq 1 $i`
    do
        printf "* "
    done
    echo
done

echo "Pattern 2: Inverted triangle"
for i in 5 4 3 2 1
do
    for j in `seq 1 $i`
    do
        printf "* "
    done
    echo
done

echo "Pattern 3: Number triangle"
for i in 1 2 3 4 5
do
    for j in `seq 1 $i`
    do
        printf "$j "
    done
    echo
done

echo "Pattern 4: Pyramid"
for i in 1 2 3 4 5
do
    for s in `seq 1 \`expr 5 - $i\``
    do
        printf " "
    done
    for j in `seq 1 $i`
    do
        printf "* "
    done
    echo
done

# PRACTICAL 9: Printing patterns using for loops
#
# Syntax:  for variable in list; do commands; done   The loop runs once for every item in the list.
# seq 1 $i prints the numbers 1 to i, so  for j in `seq 1 $i`  runs j = 1 .. i times.
# Patterns use a nested loop: the OUTER loop controls the rows (i) and the INNER loop prints the columns (j) of that row.
# printf prints without a newline, so the stars stay on one line; echo with no text prints the newline that ends the row.
# Right triangle: row i has i stars.   Inverted triangle: rows go from 5 down to 1.   Number triangle: prints the column number j.
# Pyramid: each row first prints (5 - i) spaces, then i stars, which centres the stars.
