#!/bin/sh
hour=`date +%H`
user=`whoami`
if [ $hour -lt 12 ]; then
    echo "Good Morning, $user"
elif [ $hour -lt 17 ]; then
    echo "Good Afternoon, $user"
else
    echo "Good Evening, $user"
fi

# PRACTICAL 6: Say Good Morning / Afternoon / Evening when you log in
#
# date +%H prints the current hour in 24-hour format (00 to 23). The result is stored in the variable hour.
# if ... elif ... else ... fi chooses one message: hour below 12 is morning, 12 to 16 is afternoon, otherwise evening.
# whoami gives the logged-in user name, used to personalize the greeting.
# To run it automatically at login, add this script's command at the end of ~/.bashrc or ~/.profile (for example: sh /home/user/greeting.sh). Those files are executed each time you log in or open a terminal.
