#include <stdio.h>

int main()
{
    int n, m, i, j, k;
    int alloc[10][10], max[10][10], need[10][10], avail[10];
    int finish[10] = {0}, safeSeq[10], count = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);
    printf("Enter number of resource types: ");
    scanf("%d", &m);
    printf("Enter Allocation matrix:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            scanf("%d", &alloc[i][j]);
        }
    }
    printf("Enter Max matrix:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            scanf("%d", &max[i][j]);
        }
    }
    printf("Enter Available resources:\n");
    for (j = 0; j < m; j++) {
        scanf("%d", &avail[j]);
    }

    printf("\nNeed matrix:\n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < m; j++) {
            need[i][j] = max[i][j] - alloc[i][j];
            printf("%d ", need[i][j]);
        }
        printf("\n");
    }

    while (count < n) {
        int found = 0;
        for (i = 0; i < n; i++) {
            if (!finish[i]) {
                int canRun = 1;
                for (j = 0; j < m; j++) {
                    if (need[i][j] > avail[j]) {
                        canRun = 0;
                        break;
                    }
                }
                if (canRun) {
                    for (k = 0; k < m; k++) {
                        avail[k] += alloc[i][k];
                    }
                    safeSeq[count++] = i;
                    finish[i] = 1;
                    found = 1;
                }
            }
        }
        if (!found) {
            break;
        }
    }

    if (count == n) {
        printf("\nSystem is in a SAFE state.\nSafe sequence: ");
        for (i = 0; i < n; i++) {
            printf("P%d", safeSeq[i]);
            if (i < n - 1) {
                printf(" -> ");
            }
        }
        printf("\n");
    }
    else {
        printf("\nSystem is in an UNSAFE state (deadlock possible).\n");
    }
    return 0;
}

/*
PRACTICAL 13: Implementation of Banker's Algorithm (deadlock avoidance)

Deadlock: a set of processes each waiting for a resource held by another, so none can proceed. Banker's algorithm (Dijkstra) avoids deadlock by granting a request only if the system stays in a SAFE state.
Data structures (n processes, m resource types):
  Available[m]   free instances of each resource
  Max[n][m]      maximum demand of each process
  Allocation[n][m]   resources currently held by each process
  Need[n][m] = Max - Allocation   what each process may still request

Safety algorithm:
  1. Work = Available, Finish[i] = false for all processes.
  2. Find a process i with Finish[i] = false and Need[i] <= Work.
  3. Assume it runs to completion and releases its resources: Work = Work + Allocation[i]; Finish[i] = true. Repeat step 2.
  4. If every process can finish, the state is SAFE and the order found is the safe sequence. If no such process exists while some are unfinished, the state is UNSAFE.
A safe state guarantees no deadlock; an unsafe state does not always mean deadlock but it can lead to one.

Textbook example (5 processes, 3 resources): Allocation = 010, 200, 302, 211, 002; Max = 753, 322, 902, 222, 433; Available = 3 3 2. Safe sequence: P1 -> P3 -> P4 -> P0 -> P2.

Compile and run:  gcc "practical - 13 - Bankers Algorithm.c" -o banker   then   ./banker
*/
