#!/bin/sh
echo "Set 1: Printing numbers from 0 to 9 using while loop"
a=0
while [ $a -lt 10 ]
do
        echo $a
        a=`expr $a + 1`
done

echo "Set 2: To find whether a number is even or odd"
echo "Enter a number:"
read n
rem=`expr $n % 2`
if [ $rem -eq 0 ]; then
   echo "$n is Even"
else
   echo "$n is Odd"
fi

echo "Set 3: Sum of all digits of a number"
echo "Enter a number:"
read n
sum=0
while [ $n -gt 0 ]; do
   rem=`expr $n % 10`
   sum=`expr $sum + $rem`
   n=`expr $n / 10`
done
echo "Sum of digits = $sum"

# PRACTICAL 3: Shell script to print the sum of all digits of a given number
#
# Idea: repeatedly take the last digit with n % 10, add it to sum, then drop it with n / 10 (integer division) until n becomes 0.  For 342: 2, then 4, then 3, so 2+4+3 = 9.
#
# expr evaluates arithmetic. The backquotes `...` run a command and substitute its output, so  a=`expr $a + 1`  stores the result in a. Operators need spaces around them. For multiplication write expr 2 \* 3 because * is special to the shell.
# while [ condition ]; do ... done  repeats while the condition is true.
# Test operators for numbers: -lt less than, -le less or equal, -gt greater than, -ge greater or equal, -eq equal, -ne not equal.
# if [ condition ]; then ... else ... fi  is the conditional; every if is closed by fi.
# Even or odd: if n % 2 is 0 the number is even.
# Run with:  sh filename
