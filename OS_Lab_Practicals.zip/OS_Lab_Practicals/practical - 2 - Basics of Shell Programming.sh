#!/bin/sh
echo "Shell script name: $0"
echo "Logged in user: `whoami`"
variable="Hello"
echo $variable
echo "what is your name?"
read name
echo "How do you do, $name?"
read remark
echo "I am $remark too!"

# PRACTICAL 2: Basics of shell programming
#
# An operating system has two main parts: the Kernel (the nucleus, which lets hardware and software communicate) and the Shell (the outermost layer, which takes commands from the user, processes them and displays the output). It "wraps around" the OS, hence the name.
# Types of shell: the Bourne shell family (prompt $): sh (POSIX shell), ksh (Korn shell), bash (Bourne Again Shell, the most popular); and the C shell family (prompt %): csh and tcsh.
#
# Shell scripting means writing a series of commands in a file for the shell to run, so long or repeated command sequences become one simple script.
# Steps to create a script:
#   1. Create a file with an editor (vi, gedit ...) and give it the extension .sh
#   2. Start with the shebang line  #!/bin/sh
#   3. Write the commands
#   4. Save as filename.sh
#   5. Run it with  sh filename.sh  or  bash filename.sh
# #! (shebang) tells the system which interpreter should run the script.
#
# Comments start with #  and are ignored by the shell, e.g.  #this is a comment
# Variables store text or numbers. No spaces are allowed around =  (variable="Hello" is correct, variable = "Hello" is an error). The value is read with a dollar sign: echo $variable
# read name   reads a line typed by the user into the variable name.
# Special variables: $0 script name, $1 $2 ... command-line arguments, $# number of arguments.
