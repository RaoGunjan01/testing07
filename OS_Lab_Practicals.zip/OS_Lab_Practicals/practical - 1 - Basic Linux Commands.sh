#!/bin/sh
clear
dir=`mktemp -d`
cd "$dir"
echo "--- pwd ---"
pwd
echo "--- mkdir ---"
mkdir documents
mkdir documents/work
ls
echo "--- cd documents/work ---"
cd documents/work
pwd
echo "--- cd .. ---"
cd ..
pwd
cd ..
echo "--- echo ---"
echo "Hello World"
echo "--- whoami ---"
whoami
printf "line1\nHello\nline3\nline4 Aug\nline5\nline6\nline7\nline8\nline9\nline10\nline11\nline12\n" > myfile.txt
echo "second file" > yourtext.txt
echo "--- ls ---"
ls
echo "--- ls -l ---"
ls -l
echo "--- ls -a ---"
ls -a
echo "--- cat ---"
cat myfile.txt yourtext.txt
echo "--- cat /proc/cpuinfo (first 5 lines) ---"
cat /proc/cpuinfo | head -5
echo "--- cat /proc/meminfo (first 3 lines) ---"
cat /proc/meminfo | head -3
echo "--- head ---"
head myfile.txt
echo "--- tail -n 3 ---"
tail -n 3 myfile.txt
echo "--- cp ---"
cp myfile.txt newfile.txt
ls
echo "--- mv (rename) ---"
mv newfile.txt renamed.txt
ls
echo "--- mv (move into a directory) ---"
mv renamed.txt documents/
ls documents
echo "--- wc ---"
wc -l myfile.txt
wc -w myfile.txt
wc -c myfile.txt
echo "--- grep ---"
grep "Hello" myfile.txt
echo "--- pipe ---"
ls -l | grep "documents"
echo "--- free ---"
free
echo "--- man (first 5 lines) ---"
man ls 2>/dev/null | head -5
echo "--- rmdir (empty directory) ---"
mkdir emptydir
rmdir emptydir
echo "--- rm -rf (directory with files) ---"
rm -rf documents
ls
cd /
rm -rf "$dir"

# PRACTICAL 1: Study of basic commands of Linux
#
# A shell is a program that interprets the commands you type and passes them to the operating system. It is not an operating system itself, only an interface to it. BASH (Bourne Again Shell) is a free replacement for the original Bourne shell (/bin/sh) and is the default shell on most Linux systems.
#
# pwd      print the full path of the current working directory.
# cd dir   change the working directory.   cd ..   moves up one directory.
# ls       list files.  ls -l  long listing (permissions, owner, size, date).  ls -a  includes hidden files (names starting with a dot).
# cat      "catenate": prints the contents of one or more files, e.g. cat /proc/cpuinfo shows CPU details, cat /proc/meminfo shows memory details.
# head     first 10 lines of a file (head -n 5 for 5 lines).   tail  last 10 lines (tail -n 100 file).
# mv       move a file to another directory, and also rename it (there is no separate rename command).
# cp       copy files and directories (cp origfile newfile).
# mkdir    create a directory.
# rmdir    remove an EMPTY directory. To delete a directory together with its contents use rm -rf dir (-r recursive, -f force). The manual's rmdir -rf example is not valid; rmdir has no such options.
# gedit    GUI text editor used to create or open a file (gedit abc.sh). It is graphical, so this script does not call it.
# man      shows the manual page of a command (man ls).      echo  prints text.      clear  clears the screen.
# whoami   prints the name of the current (effective) user.
# wc       word count: wc -l (lines), wc -w (words), wc -c (bytes).
# grep     searches for a pattern inside files:  grep "Hello" myfile.txt
# free     shows RAM details (total, used, free).
# pipe |   sends the output of one command as the input of the next:  ls -l | grep "Aug"
#
# Run with:  sh "practical - 1 - Basic Linux Commands.sh"
