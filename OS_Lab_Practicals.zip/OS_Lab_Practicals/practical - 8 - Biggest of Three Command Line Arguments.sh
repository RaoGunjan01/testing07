#!/bin/sh
if [ $# -ne 3 ]; then
    echo "Usage: sh $0 num1 num2 num3"
    exit 1
fi
a=$1
b=$2
c=$3
if [ $a -ge $b ] && [ $a -ge $c ]; then
    big=$a
elif [ $b -ge $a ] && [ $b -ge $c ]; then
    big=$b
else
    big=$c
fi
echo "Biggest number among $a, $b and $c is $big"

# PRACTICAL 8: Biggest of three numbers given as command-line arguments
#
# Command-line arguments are the values typed after the script name, e.g.  sh big.sh 25 70 40
# Inside the script they are available as: $1 first argument, $2 second, $3 third, $0 the script name, $# the number of arguments, $@ all arguments.
# The script first checks that exactly three arguments were given ($# -ne 3) and prints a usage message and exits with status 1 otherwise.
# Each number is compared with the other two using && (AND). -ge means greater than or equal, which also handles equal numbers correctly.
# exit 1 ends the script with a non-zero status, which means "error".
