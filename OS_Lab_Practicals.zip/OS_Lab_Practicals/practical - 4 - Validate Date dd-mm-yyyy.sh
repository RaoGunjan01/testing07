#!/bin/sh
echo "Enter a date (dd-mm-yyyy):"
read input
valid=1
if ! echo "$input" | grep -Eq '^[0-9]{2}-[0-9]{2}-[0-9]{4}$'; then
    valid=0
else
    d=`echo "$input" | cut -d- -f1`
    m=`echo "$input" | cut -d- -f2`
    y=`echo "$input" | cut -d- -f3`
    d=`expr $d + 0`
    m=`expr $m + 0`
    y=`expr $y + 0`
    if [ $m -lt 1 ] || [ $m -gt 12 ] || [ $d -lt 1 ] || [ $y -lt 1 ]; then
        valid=0
    else
        case $m in
            1|3|5|7|8|10|12)
                max=31 ;;
            4|6|9|11)
                max=30 ;;
            2)
                if [ `expr $y % 400` -eq 0 ] || { [ `expr $y % 4` -eq 0 ] && [ `expr $y % 100` -ne 0 ]; }; then
                    max=29
                else
                    max=28
                fi ;;
        esac
        if [ $d -gt $max ]; then
            valid=0
        fi
    fi
fi
if [ $valid -eq 1 ]; then
    echo "$input is a valid date"
else
    echo "$input is not a valid date"
fi

# PRACTICAL 4: Validate an entered date (dd-mm-yyyy)
#
# Step 1 - format check: grep -Eq '^[0-9]{2}-[0-9]{2}-[0-9]{4}$' accepts exactly two digits, a dash, two digits, a dash and four digits. -E means extended regular expressions, -q means quiet (only the exit status is used). ^ and $ anchor the start and end of the text.
# Step 2 - split the date with cut -d- -f1 (delimiter -, field 1 = day), f2 = month, f3 = year.
# Step 3 - expr $d + 0 converts "08" to the number 8 (a leading zero would otherwise be a problem).
# Step 4 - range check: month 1..12, day at least 1.
# Step 5 - days in the month using case: 31 days for months 1,3,5,7,8,10,12; 30 days for 4,6,9,11; February has 28 days, or 29 in a leap year.
# Leap year rule: divisible by 400, OR divisible by 4 but not by 100.
# case ... esac is the shell's switch statement; ;; ends each branch; | separates alternative patterns.
# || means OR and && means AND between test commands.
