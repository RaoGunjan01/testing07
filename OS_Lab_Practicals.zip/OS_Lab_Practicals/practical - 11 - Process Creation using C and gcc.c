#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        exit(1);
    }
    if (pid == 0) {
        printf("Child (PID %d) running the ls command:\n", getpid());
        execlp("ls", "ls", "-l", NULL);
        perror("execlp");
        exit(1);
    }
    else {
        int status;
        waitpid(pid, &status, 0);
        printf("Parent (PID %d): child %d finished with status %d\n", getpid(), pid, WEXITSTATUS(status));
    }
    return 0;
}

/*
PRACTICAL 11: Process creation using C (use of the gcc compiler)

gcc is the GNU C compiler. Steps:
  1. Write the program in a file, e.g. process.c
  2. Compile:  gcc process.c -o process      (-o names the output file; add -Wall to show warnings)
  3. Run:      ./process

Process creation calls:
  fork()    creates a child that is a copy of the parent. Returns 0 in the child, the child's PID in the parent, -1 on failure.
  exec()    family (execlp, execl, execvp ...) REPLACES the current process image with a new program. If it succeeds, the statements after it never run; if they do run, exec failed (hence perror).
  wait() / waitpid()   the parent waits for a child to terminate and collects its exit status (WEXITSTATUS extracts it).
fork() followed by exec() is how a shell starts a command: the shell forks, the child execs the program, and the shell waits.
Process states: new, ready, running, waiting, terminated. A child that has finished but has not been waited for is a zombie; a child whose parent has died is an orphan.
*/
