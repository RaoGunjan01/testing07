#!/bin/sh
echo "Enter file name:"
read fname
if [ -e "$fname" ]; then
    echo "$fname exists"
    if [ -f "$fname" ]; then
        echo "It is a regular file"
    elif [ -d "$fname" ]; then
        echo "It is a directory"
    fi
else
    echo "$fname does not exist"
fi

# PRACTICAL 10: Determine whether a given file exists
#
# File test operators used inside [ ]:
#   -e file   true if the file or directory exists
#   -f file   true if it exists and is a regular file
#   -d file   true if it exists and is a directory
#   -r / -w / -x file   true if it is readable / writable / executable
#   -s file   true if it exists and is not empty
# The file name is read with read and quoted ("$fname") so names containing spaces work.
# The script first tests existence with -e and then reports whether it is a file or a directory.
