#!/bin/sh
echo "Enter a string:"
read str
reversed=`echo "$str" | rev`
if [ "$str" = "$reversed" ]; then
    echo "$str is a palindrome"
else
    echo "$str is not a palindrome"
fi

# PRACTICAL 5: Check whether an entered string is a palindrome
#
# A palindrome reads the same forwards and backwards (madam, level, 121).
# The rev command prints each line with its characters in reverse order. echo "$str" | rev pipes the string into rev, and the backquotes capture the result in the variable reversed.
# The string is then compared with the original. For strings use = (or !=) inside [ ]; the numeric operators -eq, -lt etc. are only for numbers.
# Always put variables in double quotes inside [ ] so that strings containing spaces or empty strings do not break the test.
# The comparison is case-sensitive, so Madam is not a palindrome here. To ignore case convert both sides first, e.g. with tr 'A-Z' 'a-z'.
