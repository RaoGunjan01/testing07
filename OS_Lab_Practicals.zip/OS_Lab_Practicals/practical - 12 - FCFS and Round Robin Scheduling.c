#include <stdio.h>

void fcfs()
{
    int n, i, j, t;
    int at[20], bt[20], pid[20], st[20], ct[20], tat[20], wt[20];
    float totalWT = 0, totalTAT = 0;
    printf("Enter number of processes: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        pid[i] = i + 1;
        printf("Enter arrival time and burst time of P%d: ", i + 1);
        scanf("%d %d", &at[i], &bt[i]);
    }
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (at[j] > at[j + 1]) {
                t = at[j]; at[j] = at[j + 1]; at[j + 1] = t;
                t = bt[j]; bt[j] = bt[j + 1]; bt[j + 1] = t;
                t = pid[j]; pid[j] = pid[j + 1]; pid[j + 1] = t;
            }
        }
    }
    int time = 0;
    for (i = 0; i < n; i++) {
        if (time < at[i]) {
            time = at[i];
        }
        st[i] = time;
        time += bt[i];
        ct[i] = time;
        tat[i] = ct[i] - at[i];
        wt[i] = tat[i] - bt[i];
        totalWT += wt[i];
        totalTAT += tat[i];
    }
    printf("\nProcess\tAT\tBT\tCT\tTAT\tWT\n");
    for (i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n", pid[i], at[i], bt[i], ct[i], tat[i], wt[i]);
    }
    printf("\nGantt Chart:\n");
    for (i = 0; i < n; i++) {
        printf("| P%d (%d-%d) ", pid[i], st[i], ct[i]);
    }
    printf("|\n");
    printf("Average Waiting Time = %.2f\n", totalWT / n);
    printf("Average Turnaround Time = %.2f\n", totalTAT / n);
}

void roundRobin()
{
    int n, i, tq, remaining, time = 0, run;
    int bt[20], rem[20], ct[20], tat[20], wt[20];
    float totalWT = 0, totalTAT = 0;
    printf("Enter number of processes: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        printf("Enter burst time of P%d: ", i + 1);
        scanf("%d", &bt[i]);
        rem[i] = bt[i];
    }
    printf("Enter time quantum: ");
    scanf("%d", &tq);
    remaining = n;
    printf("\nGantt Chart:\n");
    while (remaining > 0) {
        for (i = 0; i < n; i++) {
            if (rem[i] > 0) {
                run = (rem[i] > tq) ? tq : rem[i];
                printf("| P%d (%d-%d) ", i + 1, time, time + run);
                time += run;
                rem[i] -= run;
                if (rem[i] == 0) {
                    ct[i] = time;
                    remaining--;
                }
            }
        }
    }
    printf("|\n");
    printf("\nProcess\tBT\tCT\tTAT\tWT\n");
    for (i = 0; i < n; i++) {
        tat[i] = ct[i];
        wt[i] = tat[i] - bt[i];
        totalWT += wt[i];
        totalTAT += tat[i];
        printf("P%d\t%d\t%d\t%d\t%d\n", i + 1, bt[i], ct[i], tat[i], wt[i]);
    }
    printf("Average Waiting Time = %.2f\n", totalWT / n);
    printf("Average Turnaround Time = %.2f\n", totalTAT / n);
}

int main()
{
    int choice;
    do {
        printf("\n1. FCFS\n2. Round Robin\n3. Exit\nEnter your choice: ");
        scanf("%d", &choice);
        if (choice == 1) {
            fcfs();
        }
        else if (choice == 2) {
            roundRobin();
        }
    } while (choice != 3);
    return 0;
}

/*
PRACTICAL 12: Implementation of FCFS and Round Robin CPU scheduling

CPU scheduling decides which ready process gets the CPU next.
Terms: Arrival Time (AT) - when the process enters the ready queue. Burst Time (BT) - CPU time needed. Completion Time (CT) - when it finishes.
  Turnaround Time (TAT) = CT - AT        Waiting Time (WT) = TAT - BT
A Gantt chart shows the order and time slots in which processes run.

FCFS (First Come First Served): non-preemptive; processes run in the order they arrive, like a queue. Simple, but one long process makes the others wait (convoy effect). The program sorts by arrival time, and if the CPU is idle it jumps to the next arrival time.
Example (AT,BT): P1(0,5) P2(1,3) P3(2,8) gives CT = 5, 8, 16; WT = 0, 4, 6; average WT = 3.33.

Round Robin: preemptive; each process runs for at most one time quantum (time slice), then goes to the back of the queue if unfinished. Fair and good for time-sharing systems. A very large quantum makes it behave like FCFS; a very small one causes too many context switches. This program assumes all processes arrive at time 0.
Example: BT = 24, 3, 3 with quantum 4 gives WT = 6, 4, 7; average WT = 5.67.

Compile and run:  gcc "practical - 12 - FCFS and Round Robin Scheduling.c" -o sched   then   ./sched
*/
