#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main()
{
    pid_t pid = fork();
    if (pid < 0) {
        printf("Fork failed\n");
        return 1;
    }
    else if (pid == 0) {
        printf("Child process: PID = %d, Parent PID = %d\n", getpid(), getppid());
    }
    else {
        wait(NULL);
        printf("Parent process: PID = %d, Child PID = %d\n", getpid(), pid);
    }
    return 0;
}

/*
PRACTICAL 7: Create a child process in C

A process is a program in execution. In Unix/Linux a new process is created with the system call fork().
fork() duplicates the calling (parent) process. After the call both processes continue from the next statement, and fork() returns a different value in each:
  negative  - fork failed, no child was created
  0         - returned to the CHILD process
  positive  - returned to the PARENT, and the value is the child's process ID (PID)
getpid() returns the current process's PID and getppid() returns the parent's PID.
wait(NULL) makes the parent pause until the child finishes, so the child's message always prints first and no zombie process is left behind.
Header files: unistd.h (fork, getpid), sys/wait.h (wait), sys/types.h (pid_t).
Compile and run:  gcc "practical - 7 - Create a Child Process in C.c" -o child   then   ./child
*/
